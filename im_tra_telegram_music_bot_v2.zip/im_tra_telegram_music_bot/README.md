# I'M TRA Telegram Music Bot

**I'M TRA** គឺជា Telegram bot សម្រាប់ស្វែងរក audio តាមពាក្យបញ្ជា `/song name` និងទទួល link ពី YouTube ឬ Spotify។ ពេលប្រើ Spotify link, bot នឹងយក metadata ពី Spotify ហើយស្វែងរក audio ដែលពាក់ព័ន្ធនៅលើ YouTube ព្រោះ Spotify មិនផ្តល់ download audio file ដោយផ្ទាល់សម្រាប់ bot ទេ។

> សូមប្រើ bot នេះតែជាមួយមាតិកាដែលអ្នកមានសិទ្ធិប្រើប្រាស់ ឬមាតិកាដែលអនុញ្ញាតឲ្យ download/share តាមច្បាប់ និងលក្ខខណ្ឌសេវាកម្មរបស់ platform នីមួយៗ។

## មុខងារ

| មុខងារ | ពិពណ៌នា |
| --- | --- |
| `/start` | បង្ហាញសារស្វាគមន៍ និងរបៀបប្រើ។ |
| `/song name` | ស្វែងរកបទតាមឈ្មោះ ហើយផ្ញើជា audio file។ |
| YouTube link | ទាញយក audio ពី YouTube link ដែលបានផ្ញើ។ |
| Spotify link | បម្លែង Spotify track metadata ទៅជា search query ហើយស្វែងរកលើ YouTube។ |
| MP3 conversion | បើ server មាន `ffmpeg`, bot នឹង convert audio ទៅជា MP3 192kbps។ បើមិនមាន `ffmpeg`, bot នឹងផ្ញើ best available audio format។ |

## ដំឡើងលើ Ubuntu/VPS (Polling Mode)

ដំបូងត្រូវដំឡើង Python, ffmpeg និង dependencies។ `ffmpeg` សំខាន់សម្រាប់បម្លែង audio ទៅ MP3។

```bash
sudo apt update
sudo apt install -y python3 python3-pip ffmpeg
cd im_tra_telegram_music_bot
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

បន្ទាប់មកបង្កើត file `.env` ពី `.env.example` ហើយដាក់ Telegram bot token របស់អ្នក។

```bash
cp .env.example .env
nano .env
```

ក្នុង `.env` ត្រូវដាក់បែបនេះ (សម្រាប់ polling mode)៖

```env
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN
DOWNLOAD_DIR=downloads
MAX_FILE_MB=49
```

## Run bot (Polling Mode)

```bash
source .venv/bin/activate
python bot.py
```

បើដំណើរការបានត្រឹមត្រូវ អ្នកនឹងឃើញ log ប្រហែល `I'M TRA is running in polling mode`។ បន្ទាប់មកទៅ Telegram ហើយផ្ញើ `/start` ទៅ bot។

## Deploy ក្នុង Cloud (Webhook Mode)

សម្រាប់ deployment ក្នុង cloud (Render, Railway, Heroku, etc.) ត្រូវប្រើ **webhook mode** ដែលសមស្របជាង polling mode។

### ១. កំណត់ environment variables

ក្នុង `.env` ឬ cloud platform settings ដាក់៖

```env
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN
WEBHOOK_URL=https://your-domain.com/YOUR_BOT_TOKEN
PORT=8080
DOWNLOAD_DIR=downloads
MAX_FILE_MB=49
```

**ចំណាំ:** `WEBHOOK_URL` ត្រូវតែជា full URL ដែលចង់ឲ្យ Telegram ផ្ញើ updates ទៅ (ឧទាហរណ៍: `https://im-tra-d876.onrender.com/8622680181:AAED_tafgtbnHj2uiZewObaHDr7rf4s2Voo`)

### ២. Deploy ទៅ Render

```bash
# ១. Push code ទៅ GitHub
git push origin main

# ២. ក្នុង Render dashboard:
# - Create new Web Service
# - Connect GitHub repository
# - Set environment variables (BOT_TOKEN, WEBHOOK_URL, PORT)
# - Deploy
```

### ३. Deploy ទៅ Railway

```bash
# ១. Install Railway CLI
npm i -g @railway/cli

# ២. Login
railway login

# ३. Link project
railway link

# ४. Set environment variables
railway variables set BOT_TOKEN=YOUR_TOKEN
railway variables set WEBHOOK_URL=https://your-domain.com/YOUR_BOT_TOKEN
railway variables set PORT=8080

# ५. Deploy
railway up
```

## Run ជាបន្តដោយ systemd (Local VPS)

បើអ្នក host លើ VPS ផ្ទាល់របស់អ្នក ហើយចង់ឲ្យ bot online ជានិច្ច សូមបង្កើត service file៖

```bash
sudo nano /etc/systemd/system/im-tra-bot.service
```

ដាក់ content ខាងក្រោម ហើយកែ path ប្រសិនបើ project នៅទីតាំងផ្សេង៖

```ini
[Unit]
Description=I'M TRA Telegram Music Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=/home/ubuntu/im_tra_telegram_music_bot
EnvironmentFile=/home/ubuntu/im_tra_telegram_music_bot/.env
ExecStart=/home/ubuntu/im_tra_telegram_music_bot/.venv/bin/python /home/ubuntu/im_tra_telegram_music_bot/bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

បើក service៖

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now im-tra-bot
sudo systemctl status im-tra-bot
```

## សុវត្ថិភាព token

Telegram bot token គឺជា secret។ កុំបង្ហោះ `.env` ទៅ GitHub ឬផ្ញើទៅអ្នកដទៃ។ ប្រសិនបើ token ត្រូវបានបង្ហាញជាសាធារណៈ សូមទៅ BotFather ហើយ revoke/regenerate token ថ្មី។

## កំណត់ចំណាំបច្ចេកទេស

Bot នេះប្រើ `python-telegram-bot` សម្រាប់ Telegram API, `yt-dlp` សម្រាប់ download/extract audio, `python-dotenv` សម្រាប់អាន `.env`, និង `requests` សម្រាប់ទាញ Spotify oEmbed metadata។ សម្រាប់ cloud deployment ត្រូវប្រើ webhook mode ដែលលឺងទាក់ទងលើ port 8080។
